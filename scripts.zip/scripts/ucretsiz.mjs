// Ücretsiz beyin kurulumu: server/.env dosyasını hazırlar.
//   npm run ucretsiz -- gemini <ANAHTAR>
//   npm run ucretsiz -- ollama <model-adı>
// Mevcut server/.env varsa önce server/.env.yedek olarak saklanır.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const tpl = path.join(root, 'server', '.env.ucretsiz.example');
const out = path.join(root, 'server', '.env');
const [kind, arg] = process.argv.slice(2);

const usage = () => {
  console.error('Kullanım:\n  npm run ucretsiz -- gemini <GEMINI_API_ANAHTARI>   (anahtar: https://aistudio.google.com/apikey)\n  npm run ucretsiz -- ollama <model-adı>             (ör. ollama pull ile indirdiğiniz model)');
  process.exit(1);
};
if (!['gemini', 'ollama'].includes(kind) || !arg) usage();
if (/\s/.test(arg)) { console.error('Anahtar/model adında boşluk olamaz.'); process.exit(1); }

// Yalnızca ŞABLONUN ilk (etkin) bölümünü kullan; açıklama satırları korunur.
let lines = fs.readFileSync(tpl, 'utf8').split('\n');
const set = (key, val) => {
  const i = lines.findIndex(l => l.startsWith(key + '='));
  if (i >= 0) lines[i] = `${key}=${val}`; else lines.push(`${key}=${val}`);
};
if (kind === 'gemini') {
  set('LLM_API_KEY', arg);
} else {
  set('LLM_BASE_URL', 'http://localhost:11434/v1');
  set('LLM_API_KEY', '');
  set('CHAT_MODEL', arg);
  set('VISION_MODEL', '');
  set('STT_MODEL', '');
}

if (fs.existsSync(out)) {
  fs.copyFileSync(out, out + '.yedek');
  console.log('Mevcut server/.env, server/.env.yedek olarak saklandı.');
}
fs.writeFileSync(out, lines.join('\n'));
console.log(`server/.env hazır (${kind}).`);
if (kind === 'ollama') console.log(`Önce: ollama pull ${arg}   ·   sonra: npm run dev`);
else console.log('Şimdi: npm run dev   ·   Giriş kontrolü: npm run test');
