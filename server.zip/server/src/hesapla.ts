// Güvenli hesap makinesi. eval/Function YOK: ifade küçük bir ayrıştırıcıyla çözülür.
// Desteklenen: + - * / ^ ( ), ondalık için nokta, sayıdan sonra % (yüzde: 20% = 0,2),
// sabitler pi ve e, fonksiyonlar sqrt abs sin cos tan (radyan) ln log10 round floor ceil min max mod pow.

const FONK: Record<string, (...a: number[]) => number> = {
  sqrt: Math.sqrt, abs: Math.abs, sin: Math.sin, cos: Math.cos, tan: Math.tan,
  ln: Math.log, log10: Math.log10, round: Math.round, floor: Math.floor, ceil: Math.ceil,
  min: Math.min, max: Math.max, mod: (a, b) => a % b, pow: Math.pow,
};
const SABIT: Record<string, number> = { pi: Math.PI, e: Math.E };

type Tok = { t: 'sayi'; v: number } | { t: 'ad'; v: string } | { t: 'op'; v: string };

function tokenize(src: string): Tok[] {
  const s = src.toLowerCase().replace(/×/g, '*').replace(/÷/g, '/').replace(/[\s_]/g, '');
  const out: Tok[] = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (/[0-9.]/.test(c)) {
      let j = i;
      while (j < s.length && /[0-9.]/.test(s[j])) j++;
      const raw = s.slice(i, j);
      if (!/^(\d+\.?\d*|\.\d+)$/.test(raw)) throw new Error(`Geçersiz sayı: ${raw}`);
      out.push({ t: 'sayi', v: Number(raw) });
      i = j;
    } else if (/[a-z]/.test(c)) {
      let j = i;
      while (j < s.length && /[a-z0-9]/.test(s[j])) j++;
      out.push({ t: 'ad', v: s.slice(i, j) });
      i = j;
    } else if ('+-*/^()%,'.includes(c)) {
      out.push({ t: 'op', v: c });
      i++;
    } else {
      throw new Error(`Tanınmayan karakter: ${c}`);
    }
  }
  return out;
}

export function hesapla(ifade: string): number {
  const src = String(ifade ?? '');
  if (!src.trim()) throw new Error('İfade boş');
  if (src.length > 200) throw new Error('İfade çok uzun');
  const toks = tokenize(src);
  let p = 0;
  let derin = 0;
  const peek = () => toks[p];
  const isOp = (v: string) => peek()?.t === 'op' && (peek() as { v: string }).v === v;

  function expr(): number {
    let x = term();
    while (isOp('+') || isOp('-')) {
      const op = (toks[p++] as { v: string }).v;
      const y = term();
      x = op === '+' ? x + y : x - y;
    }
    return x;
  }
  function term(): number {
    let x = unary();
    while (isOp('*') || isOp('/')) {
      const op = (toks[p++] as { v: string }).v;
      const y = unary();
      if (op === '/' && y === 0) throw new Error('Sıfıra bölme');
      x = op === '*' ? x * y : x / y;
    }
    return x;
  }
  function unary(): number {
    if (isOp('-')) { p++; return -unary(); }
    if (isOp('+')) { p++; return unary(); }
    return power();
  }
  function power(): number {
    const b = postfix();
    if (isOp('^')) { p++; return Math.pow(b, unary()); }
    return b;
  }
  function postfix(): number {
    let x = primary();
    while (isOp('%')) { p++; x = x / 100; }
    return x;
  }
  function primary(): number {
    if (++derin > 60) throw new Error('İfade çok iç içe');
    const t = toks[p++];
    if (!t) throw new Error('İfade eksik');
    let v: number;
    if (t.t === 'sayi') v = t.v;
    else if (t.t === 'ad') {
      if (isOp('(')) {
        p++;
        const args: number[] = [];
        if (!isOp(')')) {
          args.push(expr());
          while (isOp(',')) { p++; args.push(expr()); }
        }
        if (!isOp(')')) throw new Error('Parantez kapanmadı');
        p++;
        const f = FONK[t.v];
        if (!f) throw new Error(`Bilinmeyen fonksiyon: ${t.v}`);
        v = f(...args);
      } else if (t.v in SABIT) v = SABIT[t.v];
      else throw new Error(`Bilinmeyen ad: ${t.v}`);
    } else if (t.v === '(') {
      v = expr();
      if (!isOp(')')) throw new Error('Parantez kapanmadı');
      p++;
    } else throw new Error(`Beklenmeyen: ${t.v}`);
    derin--;
    return v;
  }

  const sonuc = expr();
  if (p < toks.length) throw new Error('İfadenin sonunda fazlalık var');
  if (!Number.isFinite(sonuc)) throw new Error('Sonuç sayı değil');
  return Number(sonuc.toPrecision(12));
}
