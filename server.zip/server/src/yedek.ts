// Yedek / geri yükleme. Ücretsiz sunucu uyuyunca dosyalar silinir; telefon (tarayıcı) kendi kopyasını saklar ve
// sunucu "taze" (boş) açılınca geri yükler. Yalnızca aşağıdaki beyaz listedeki dosyalar, boyut sınırıyla.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const DATA = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'data');
export const YEDEK_DOSYALARI = ['state.json', 'profile.json', 'memory.json', 'kitaplik.json', 'home.json'] as const;
const MAX_DOSYA = 900_000; // bayt; tarayıcı deposu (~5 MB) dolmasın
const ANAHTARLAR = ['state.json', 'profile.json', 'memory.json', 'kitaplik.json']; // "taze mi" kararı bunlara bakar

export interface Yedek {
  v: 1;
  at: string;
  dosyalar: Record<string, string>;
}

export function sunucuTazeMi(): boolean {
  return !ANAHTARLAR.some(f => fs.existsSync(path.join(DATA, f)));
}

/** `canliState`: bellekteki durum (state.json diske henüz yazılmamış olabilir). */
export function yedekAl(canliState: unknown): Yedek {
  const dosyalar: Record<string, string> = {};
  for (const f of YEDEK_DOSYALARI) {
    let txt: string | null = null;
    if (f === 'state.json') txt = JSON.stringify(canliState);
    else {
      try { txt = fs.readFileSync(path.join(DATA, f), 'utf8'); } catch { txt = null; }
    }
    if (txt && txt.length <= MAX_DOSYA) dosyalar[f] = txt;
  }
  return { v: 1, at: new Date().toISOString(), dosyalar };
}

/** Yedeği doğrular ve beyaz listedeki dosyaları yazar. Yazılan dosya adlarını döndürür. */
export function yedegiYaz(y: unknown): { yazilan: string[]; state?: unknown } {
  const d = (y as Yedek | undefined)?.dosyalar;
  if (!d || typeof d !== 'object') throw new Error('geçersiz yedek');
  fs.mkdirSync(DATA, { recursive: true });
  const yazilan: string[] = [];
  let state: unknown;
  for (const f of YEDEK_DOSYALARI) {
    const txt = (d as Record<string, unknown>)[f];
    if (typeof txt !== 'string' || !txt || txt.length > MAX_DOSYA) continue;
    let parsed: unknown;
    try { parsed = JSON.parse(txt); } catch { continue; }
    if (parsed === null || typeof parsed !== 'object') continue;
    if (f === 'state.json') { state = parsed; continue; } // state.json'u sunucu kendi yazar (bellekle birlikte)
    fs.writeFileSync(path.join(DATA, f), txt);
    yazilan.push(f);
  }
  return { yazilan, state };
}
