// Namaz vakitleri (Aladhan API, Diyanet yöntemi). Anahtar gerekmez. Ağ hatasında araç "hata" döner; model uydurmaz.
const FOLD: Record<string, string> = { 'İ': 'I', 'ı': 'i', 'ş': 's', 'Ş': 'S', 'ğ': 'g', 'Ğ': 'G', 'ü': 'u', 'Ü': 'U', 'ö': 'o', 'Ö': 'O', 'ç': 'c', 'Ç': 'C' };
const ascii = (s: string) => s.replace(/[İışŞğĞüÜöÖçÇ]/g, c => FOLD[c] ?? c);

export interface NamazSonucu {
  sehir: string;
  tarih: string;
  vakitler: { imsak: string; gunes: string; ogle: string; ikindi: string; aksam: string; yatsi: string };
  sonraki: { ad: string; saat: string; kalan: string } | null;
  kaynak: string;
}

const cache = new Map<string, { at: number; v: NamazSonucu }>();

function istanbulParcalar(now: Date) {
  const f = new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Istanbul', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
  const p: Record<string, string> = {};
  for (const x of f.formatToParts(now)) p[x.type] = x.value;
  return { gun: `${p.day}-${p.month}-${p.year}`, dakika: Number(p.hour) * 60 + Number(p.minute) };
}

const dk = (hhmm: string) => { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; };

export async function namazVakitleri(sehir?: string, now = new Date()): Promise<NamazSonucu | { hata: string }> {
  const ad = (sehir || process.env.WEATHER_CITY || 'Istanbul').trim() || 'Istanbul';
  const { gun, dakika } = istanbulParcalar(now);
  const key = `${ascii(ad).toLowerCase()}|${gun}`;
  let v = cache.get(key)?.v;
  if (!v) {
    const url = `https://api.aladhan.com/v1/timingsByCity/${gun}?city=${encodeURIComponent(ascii(ad))}&country=Turkey&method=13`;
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 7000);
    try {
      const r = await fetch(url, { signal: ctl.signal });
      if (!r.ok) return { hata: `Namaz vakitleri alınamadı (${r.status}). Saat uydurma; alınamadığını söyle.` };
      const j: any = await r.json();
      const t = j?.data?.timings;
      if (!t?.Fajr) return { hata: `"${ad}" için namaz vakti bulunamadı. Saat uydurma.` };
      const temiz = (x: string) => String(x).slice(0, 5);
      v = {
        sehir: ad, tarih: gun,
        vakitler: { imsak: temiz(t.Fajr), gunes: temiz(t.Sunrise), ogle: temiz(t.Dhuhr), ikindi: temiz(t.Asr), aksam: temiz(t.Maghrib), yatsi: temiz(t.Isha) },
        sonraki: null,
        kaynak: 'Aladhan · Diyanet yöntemi',
      };
      cache.set(key, { at: Date.now(), v });
    } catch {
      return { hata: 'Namaz vakitleri servisine ulaşılamadı. Saat uydurma; alınamadığını söyle.' };
    } finally {
      clearTimeout(timer);
    }
  }
  // Şimdiye göre sıradaki vakit (yatsıdan sonra yarının imsağı: yaklaşık, bugünün saatiyle)
  const sira: [string, string][] = [['İmsak', v.vakitler.imsak], ['Güneş', v.vakitler.gunes], ['Öğle', v.vakitler.ogle], ['İkindi', v.vakitler.ikindi], ['Akşam', v.vakitler.aksam], ['Yatsı', v.vakitler.yatsi]];
  let sonraki: NamazSonucu['sonraki'] = null;
  for (const [vad, saat] of sira) {
    if (dk(saat) > dakika) { sonraki = { ad: vad, saat, kalan: kalan(dk(saat) - dakika) }; break; }
  }
  if (!sonraki) sonraki = { ad: 'İmsak (yarın, yaklaşık)', saat: v.vakitler.imsak, kalan: kalan(24 * 60 - dakika + dk(v.vakitler.imsak)) };
  return { ...v, sonraki };
}

function kalan(dkk: number): string {
  const s = Math.floor(dkk / 60), m = dkk % 60;
  return s ? `${s} saat ${m} dk` : `${m} dk`;
}
