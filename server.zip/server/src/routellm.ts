import 'dotenv/config';

// Sağlayıcı: OpenAI uyumlu (/chat/completions) herhangi bir uç olur. Varsayılan Abacus RouteLLM (ücretli).
// Ücretsiz beyin için LLM_BASE_URL + LLM_API_KEY kullanın (Gemini, Ollama...). Eski adlar (ROUTELLM_BASE_URL,
// ABACUS_API_KEY) çalışmaya devam eder. Bkz. server/.env.ucretsiz.example
export const BASE_URL = (process.env.LLM_BASE_URL || process.env.ROUTELLM_BASE_URL || 'https://routellm.abacus.ai/v1').replace(/\/+$/, '');
/** Abacus'a özgü varsayılanlar (flux2 görsel, gpt-audio ses...) yalnızca Abacus uçunda geçerli */
export const IS_ABACUS = /abacus\.ai/i.test(BASE_URL);
/** Yerel sunucu (Ollama, LM Studio...) anahtar istemez */
const LOCAL = /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:|\/|$)/i.test(BASE_URL);
export const API_KEY = process.env.LLM_API_KEY || process.env.ABACUS_API_KEY || (LOCAL ? 'yerel' : '');
export const CHAT_MODEL = process.env.CHAT_MODEL || 'route-llm';
export const MOCK = process.env.MOCK === '1' || !API_KEY;

export class RouteLLMError extends Error {
  constructor(public status: number, public body: string) {
    super(`RouteLLM ${status}: ${body.slice(0, 300)}`);
  }
}

async function routellmOnce<T = any>(path: string, body?: unknown, method = body ? 'POST' : 'GET'): Promise<T> {
  const res = await fetch(BASE_URL + path, {
    method,
    headers: { Authorization: `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  if (!res.ok) throw new RouteLLMError(res.status, text);
  return JSON.parse(text) as T;
}

export async function routellm<T = any>(path: string, body?: unknown, method = body ? 'POST' : 'GET'): Promise<T> {
  if (path === '/chat/completions' && body && typeof (body as { model?: unknown }).model === 'string') {
    return withModelFallback(body as Record<string, any>, b => routellmOnce<T>(path, b, method));
  }
  return routellmOnce<T>(path, body, method);
}

// ---------------------------------------------------------------------------------------------------------
// Model yedeği (Gemini): Google modelleri sık değiştirir ("gemini-2.5-flash yeni kullanıcılara kapalı" gibi).
// İstenen model kullanılamıyorsa sağlayıcının /models listesinden en yeni "flash" modeli bulunur, denenir ve
// çalışan ad hatırlanır. Böylece model kapanınca Jarvis bozulmaz. Abacus ve yerel sağlayıcıda devre dışı.
// ---------------------------------------------------------------------------------------------------------
const GEMINI = process.env.LLM_UYUM === 'gemini' || /generativelanguage\.googleapis\.com/i.test(BASE_URL);
const resolved = new Map<string, string>();
let noReasoning = process.env.LLM_DUSUNME === 'kapali';
let modelList: { at: number; ids: string[] } | null = null;

/** Model adının sorun olduğunu gösteren cevaplar (404 kapandı/bulunamadı, 429 ücretsiz kotası 0) */
function badModel(status: number, body: string): boolean {
  if ((status === 404 || status === 400) && /model/i.test(body)
    && /(no longer available|not found|not supported|not available|does not exist|unsupported|is deprecated)/i.test(body)) return true;
  return status === 429 && /limit:\s*0\b/.test(body);
}

function modelRank(id: string): number[] {
  // Sürümü parça parça karşılaştır: 3.10, 3.9'dan yeni kabul edilir.
  const match = /^gemini-(\d+(?:\.\d+)?)/i.exec(id);
  const version = (match?.[1] ?? '0').split('.').map(Number);
  return [-(version[0] ?? 0), -(version[1] ?? 0), /lite/i.test(id) ? 1 : 0, /preview|exp/i.test(id) ? 1 : 0];
}

async function candidateModels(): Promise<string[]> {
  // Model kataloğunu kısa süre önbelleğe alır; yeni modeller en geç 10 dakika sonra görünür.
  if (!modelList || Date.now() - modelList.at > 10 * 60_000) {
    const j = await routellmOnce<{ data?: { id?: string }[]; models?: { name?: string }[] }>('/models');
    const ids = [...(j.data ?? []).map(m => m.id ?? ''), ...(j.models ?? []).map(m => m.name ?? '')]
      .map(x => x.replace(/^models\//, '')).filter(Boolean);
    modelList = { at: Date.now(), ids: [...new Set(ids)] };
  }
  const ids = modelList.ids.filter(id =>
    /^gemini-\d/i.test(id) && /flash/i.test(id) &&
    !/(image|tts|audio|live|embed|vision|robotic|computer|thinking|8b)/i.test(id)
  );
  // Önce kararlı sürümler; preview/experimental yalnızca başka seçenek yoksa yedek olur.
  const stable = ids.filter(id => !/(preview|exp)/i.test(id));
  const rank = (a: string, b: string) => {
    const ra = modelRank(a), rb = modelRank(b);
    for (let i = 0; i < ra.length; i++) if (ra[i] !== rb[i]) return ra[i] - rb[i];
    return a.localeCompare(b);
  };
  return (stable.length ? stable : ids).sort(rank);
}

async function withModelFallback<T>(body: Record<string, any>, run: (b: Record<string, any>) => Promise<T>): Promise<T> {
  const asked = String(body.model);
  if (!GEMINI) return run(body);

  const auto = /^(auto|latest|latest-gemini-flash)$/i.test(asked);
  const tried = new Set<string>();
  let lastErr: unknown;
  let choices: string[] = [];

  // AUTO/LATEST seçeneği her istekte model kataloğunu kontrol eder (katalog en fazla 10 dk önbelleklenir).
  // Sabit model seçilmişse önce onu dener; yalnızca model/kota hatasında yedeğe geçer.
  if (auto) {
    try { choices = await candidateModels(); }
    catch (e) {
      throw new RouteLLMError(503, `Gemini model listesi alınamadı: ${String((e as Error)?.message ?? e)}`);
    }
    if (!choices.length) throw new RouteLLMError(503, 'Gemini /models listesinden kullanılabilir Flash modeli bulunamadı.');
  } else {
    choices = [resolved.get(asked) ?? asked];
  }

  for (let attempt = 0; attempt < 5; attempt++) {
    const model = choices.find(id => !tried.has(id));
    if (!model) break;
    tried.add(model);
    const b: Record<string, any> = { ...body, model };
    // AUTO modunda da uygulamanın gerçek model adını raporlayabilmesi için model alanı istekle birlikte kalır.
    if (!noReasoning && !('reasoning_effort' in b)) b.reasoning_effort = process.env.LLM_DUSUNME || 'low';
    try {
      const r = await run(b);
      if (!auto && model !== asked) resolved.set(asked, model);
      if (auto) console.log(`[model] otomatik seçim: ${model}`);
      return r;
    } catch (e) {
      lastErr = e;
      if (!(e instanceof RouteLLMError)) throw e;
      if (e.status === 400 && /reasoning|thinking/i.test(e.body) && !noReasoning) {
        noReasoning = true;
        console.log('[model] düşünme ayarı reddedildi; ayarsız yeniden deneniyor');
        tried.delete(model);
        continue;
      }
      if (!badModel(e.status, e.body)) throw e;
      // Otomatik modda zaten sıralı adaylar var; sabit modelde katalogdan yedekleri getir.
      if (!auto) {
        try {
          const fallback = await candidateModels();
          choices = [model, ...fallback.filter(id => id !== model)];
        } catch { /* Sağlayıcı model listesini sunmuyorsa asıl hata korunur. */ }
      }
      const next = choices.find(id => !tried.has(id));
      if (!next) throw e;
      console.log(`[model] ${model} kullanılamıyor (${e.status}); ${next} deneniyor`);
    }
  }
  throw lastErr ?? new RouteLLMError(503, 'Kullanılabilir Gemini Flash modeli bulunamadı.');
}

/** Kullanıcıya gösterilecek, ne yapılacağını söyleyen Türkçe hata metni */
export function friendlyError(e: unknown): string {
  const raw = String((e as Error)?.message ?? e);
  if (e instanceof RouteLLMError) {
    const { status, body } = e;
    if (status === 401 || status === 403 || /invalid api key|api key not valid|permission[_ ]denied/i.test(body)) {
      return 'Yapay zekâ anahtarı geçersiz ya da istek yanlış adrese gidiyor. Render → Environment: anahtar (LLM_API_KEY ya da ABACUS_API_KEY) Gemini anahtarın olmalı, adres (LLM_BASE_URL ya da ROUTELLM_BASE_URL) https://generativelanguage.googleapis.com/v1beta/openai olmalı.';
    }
    if (status === 429) {
      return /limit:\s*0/.test(body)
        ? 'Bu modelin ücretsiz kotası yok. CHAT_MODEL=auto yaparak kullanılabilir Gemini Flash modellerinin otomatik seçilmesini sağlayabilirsin.'
        : 'Gemini ücretsiz limiti doldu. Birkaç dakika bekleyip tekrar dene.';
    }
    if (badModel(status, body)) {
      return 'Seçili Gemini modeli artık kullanılamıyor. CHAT_MODEL=auto ve VISION_MODEL=auto ayarlarını kullanarak mevcut Flash modelinin otomatik seçilmesini sağlayabilirsin.';
    }
    if (status >= 500) return 'Yapay zekâ sunucusu şu an yoğun ya da yanıt vermiyor. Birazdan tekrar dene.';
    return `Yapay zekâ isteği reddedildi (${status}): ${body.replace(/\s+/g, ' ').slice(0, 160)}`;
  }
  if (/fetch failed|ECONN|ENOTFOUND|ETIMEDOUT|network/i.test(raw)) return 'Yapay zekâ sunucusuna ulaşılamadı. İnternet bağlantısını kontrol et.';
  return raw;
}

export interface StreamResult {
  content: string;
  tool_calls: NonNullable<ChatMessage['tool_calls']>;
  model: string | null;
  /** İsteğin gönderilmesinden ilk içerik/araç parçasına kadar geçen süre */
  firstTokenMs: number | null;
  totalMs: number;
}

/**
 * Akışlı sohbet isteği (`stream: true`). İçerik geldikçe `onContent` çağrılır; araç çağrıları parçalardan birleştirilir.
 * Sahne JSON'u bu sayede tamamı bitmeden okunmaya başlar (ilk sahne hazır olunca TTS'i başlar).
 */
export function routellmStream(body: object, onContent?: (delta: string, full: string) => void): Promise<StreamResult> {
  return withModelFallback(body as Record<string, any>, b => routellmStreamOnce(b, onContent));
}

async function routellmStreamOnce(body: object, onContent?: (delta: string, full: string) => void): Promise<StreamResult> {
  const t0 = performance.now();
  const res = await fetch(BASE_URL + '/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...body, stream: true }),
  });
  if (!res.ok || !res.body) throw new RouteLLMError(res.status, await res.text());
  const dec = new TextDecoder();
  let buf = '';
  let content = '';
  let model: string | null = null;
  let firstTokenMs: number | null = null;
  const calls: { id: string; name: string; args: string }[] = [];
  const slotOf = new Map<number, number>();
  for await (const chunk of res.body as unknown as AsyncIterable<Uint8Array>) {
    buf += dec.decode(chunk, { stream: true });
    let nl: number;
    while ((nl = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, nl).trim();
      buf = buf.slice(nl + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim();
      if (!data || data === '[DONE]') continue;
      let j: any;
      try { j = JSON.parse(data); } catch { continue; }
      model ??= j.model ?? null;
      const d = j.choices?.[0]?.delta ?? {};
      if ((d.content || d.tool_calls) && firstTokenMs === null) firstTokenMs = Math.round(performance.now() - t0);
      for (const tc of d.tool_calls ?? []) {
        // Gemini gibi bazı OpenAI-uyumlu uçlar paralel çağrıların hepsine index 0 verir: aynı ham indekste kimlik
        // değiştiyse yeni çağrıdır. Kimliksiz devam parçaları, o ham indeksin en son yuvasına eklenir.
        const raw = tc.index ?? 0;
        let i = slotOf.get(raw);
        if (i === undefined || (tc.id && calls[i]?.id && calls[i].id !== tc.id)) { i = calls.length; slotOf.set(raw, i); }
        calls[i] ??= { id: '', name: '', args: '' };
        if (tc.id) calls[i].id = tc.id;
        if (tc.function?.name) calls[i].name += tc.function.name;
        if (tc.function?.arguments) calls[i].args += tc.function.arguments;
      }
      if (typeof d.content === 'string' && d.content) {
        content += d.content;
        onContent?.(d.content, content);
      }
    }
  }
  return {
    content,
    tool_calls: calls.filter(Boolean).map((c, i) => ({ id: c.id || `call_${i}`, type: 'function' as const, function: { name: c.name, arguments: c.args } })),
    model,
    firstTokenMs,
    totalMs: Math.round(performance.now() - t0),
  };
}

export type ContentPart =
  | { type: 'text'; text: string }
  | { type: 'image_url'; image_url: { url: string } }
  | { type: 'input_audio'; input_audio: { data: string; format: string } };

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string | null | ContentPart[];
  tool_calls?: { id: string; type: 'function'; function: { name: string; arguments: string } }[];
  tool_call_id?: string;
}

export interface ChatResponse {
  model?: string;
  choices: {
    message: ChatMessage & {
      audio?: { data: string };
      audios?: { id: string; data: string; expires_at: number; transcript: string }[];
    };
    finish_reason: string;
  }[];
}
