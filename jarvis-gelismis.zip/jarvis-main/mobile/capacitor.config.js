// Jarvis mobil kabuğu. Arayüz uygulamanın içine gömülmez: WebView, çalışan Jarvis sunucusunu açar.
// Neden: arayüzün bütün /api çağrıları göreli adresle yapılıyor; sunucudan yüklenince hiçbirine dokunmak,
// CORS açmak ya da arayüzü yeniden derleyip mağazaya yüklemek gerekmez. Sunucu güncellenince uygulama da güncellenir.
//
// Sunucu adresi (HTTPS şart: mikrofon/kamera ve iOS güvenliği için) JARVIS_URL ortam değişkeninden gelir:
//   JARVIS_URL=https://bilgisayarim.tailnet-adi.ts.net npm run sync
const url = (process.env.JARVIS_URL || '').trim().replace(/\/+$/, '');
const secure = url.startsWith('https://');

/** @type {import('@capacitor/cli').CapacitorConfig} */
const config = {
  appId: 'app.jarvis.mobil',
  appName: 'Jarvis',
  webDir: 'www',
  backgroundColor: '#04070c',
  ios: {
    contentInset: 'never', // HUD kenara kadar uzanır; çentik payını arayüzün env(safe-area-inset-*) değerleri yönetir
    backgroundColor: '#04070c',
    limitsNavigationsToAppBoundDomains: false,
  },
  android: {
    backgroundColor: '#04070c',
    allowMixedContent: false,
  },
  server: url
    ? {
        url,
        cleartext: !secure, // yalnızca yerel deneme için http://… adresine izin verir
        errorPath: 'index.html', // sunucuya ulaşılamazsa www/index.html (yeniden dene ekranı) açılır
      }
    : undefined,
};

module.exports = config;
