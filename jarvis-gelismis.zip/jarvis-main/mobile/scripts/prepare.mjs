// www/index.html: sunucuya ulaşılamadığında görünen "yeniden dene" ekranı (server.errorPath).
// Adres JARVIS_URL'den okunur ve sayfaya gömülür.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = (process.env.JARVIS_URL || '').trim().replace(/\/+$/, '');
if (!url) {
  console.error('JARVIS_URL tanımlı değil.\nÖrnek: JARVIS_URL=https://bilgisayarim.tailnet-adi.ts.net npm run add:ios');
  process.exit(1);
}
if (!/^https?:\/\//.test(url)) {
  console.error('JARVIS_URL http:// ya da https:// ile başlamalı.');
  process.exit(1);
}
if (url.startsWith('http://')) console.warn('UYARI: http adresinde mikrofon ve kamera çalışmaz. Yalnızca arayüz denemesi içindir; HTTPS kullanın.');

const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
const html = `<!doctype html>
<html lang="tr">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<title>Jarvis</title>
<style>
  :root { color-scheme: dark; }
  html, body { margin: 0; height: 100%; background: #04070c; color: #cfe8ff; font-family: -apple-system, system-ui, sans-serif; }
  main { min-height: 100%; box-sizing: border-box; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 14px; padding: calc(env(safe-area-inset-top, 0px) + 24px) 24px calc(env(safe-area-inset-bottom, 0px) + 24px); text-align: center; }
  .dot { width: 14px; height: 14px; border-radius: 50%; background: #ffb020; box-shadow: 0 0 18px #ffb020; animation: p 1.8s ease-in-out infinite; }
  @keyframes p { 50% { opacity: .35; transform: scale(.8); } }
  h1 { font-size: 15px; letter-spacing: .25em; margin: 0; font-weight: 600; }
  p { margin: 0; font-size: 14px; line-height: 1.5; opacity: .75; max-width: 320px; }
  code { font-size: 12px; opacity: .9; word-break: break-all; }
  a.btn { margin-top: 8px; padding: 12px 28px; border: 1px solid #3aa0ff; border-radius: 10px; color: #cfe8ff; text-decoration: none; font-size: 14px; letter-spacing: .1em; }
</style>
</head>
<body>
<main>
  <div class="dot"></div>
  <h1>JARVIS · ÇEVRİMDIŞI</h1>
  <p>Sunucuya ulaşılamadı. Bilgisayardaki Jarvis açık mı, tünel (Tailscale / Cloudflare) çalışıyor mu?</p>
  <code>${esc(url)}</code>
  <a class="btn" href="${esc(url)}/">YENİDEN DENE</a>
</main>
</body>
</html>
`;
fs.mkdirSync(path.join(root, 'www'), { recursive: true });
fs.writeFileSync(path.join(root, 'www', 'index.html'), html);
console.log(`www/index.html hazır (sunucu: ${url})`);
