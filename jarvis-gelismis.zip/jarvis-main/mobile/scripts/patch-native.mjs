// `cap add` ile oluşan ios/ ve android/ projelerine mikrofon-kamera izinlerini ekler. Tekrar çalıştırmak güvenlidir.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
let changed = 0;

// ---- iOS: Info.plist
const plist = path.join(root, 'ios', 'App', 'App', 'Info.plist');
if (fs.existsSync(plist)) {
  let x = fs.readFileSync(plist, 'utf8');
  const keys = {
    NSMicrophoneUsageDescription: 'Jarvis sesli komutlarınızı dinlemek ve alkışla uyanmak için mikrofonu kullanır.',
    NSCameraUsageDescription: 'Jarvis kamera cihazı, fotoğraf analizi ve El Kontrolü için kamerayı kullanır.',
    NSPhotoLibraryUsageDescription: 'Jarvis kitaplık ve fotoğraf yüklemeleri için galerinize erişir.',
  };
  for (const [k, v] of Object.entries(keys)) {
    if (x.includes(`<key>${k}</key>`)) continue;
    x = x.replace(/<\/dict>\s*<\/plist>\s*$/, `\t<key>${k}</key>\n\t<string>${v}</string>\n</dict>\n</plist>\n`);
    changed++;
  }
  fs.writeFileSync(plist, x);
  console.log('iOS Info.plist kontrol edildi.');
} else console.log('ios/ yok, atlandı.');

// ---- Android: AndroidManifest.xml
const manifest = path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifest)) {
  let x = fs.readFileSync(manifest, 'utf8');
  const perms = [
    'android.permission.RECORD_AUDIO',
    'android.permission.MODIFY_AUDIO_SETTINGS',
    'android.permission.CAMERA',
    'android.permission.WAKE_LOCK',
  ];
  const feats = [
    '<uses-feature android:name="android.hardware.camera" android:required="false" />',
    '<uses-feature android:name="android.hardware.microphone" android:required="false" />',
  ];
  const add = [];
  for (const p of perms) if (!x.includes(p)) add.push(`    <uses-permission android:name="${p}" />`);
  for (const f of feats) if (!x.includes(f.match(/android:name="([^"]+)"/)[1])) add.push(`    ${f}`);
  if (add.length) {
    x = x.replace(/<\/manifest>\s*$/, `${add.join('\n')}\n</manifest>\n`);
    changed += add.length;
    fs.writeFileSync(manifest, x);
  }
  console.log('Android manifest kontrol edildi.');
} else console.log('android/ yok, atlandı.');

console.log(changed ? `${changed} izin satırı eklendi.` : 'Eklenecek bir şey yoktu.');
